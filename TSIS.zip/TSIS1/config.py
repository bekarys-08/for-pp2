DB_HOST = "localhost"
DB_PORT = 5432
DB_NAME = "phonebook_db"
DB_USER = "postgres"
DB_PASSWORD = "270708"